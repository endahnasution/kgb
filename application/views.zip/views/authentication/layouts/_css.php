<link href="<?php echo base_url('assets');?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url('assets');?>/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url('assets');?>/vendor/AdminLTE-2.4.3/css/AdminLTE.min.css" rel="stylesheet">
<link href="<?php echo base_url('assets');?>/vendor/iCheck/square/blue.css" rel="stylesheet">
<script src="<?php echo base_url('assets');?>/vendor/jquery/jquery.min.js"></script>
