<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<?php if (ENVIRONMENT=='development'): ?>
		<b>e-SatuPintu</b> v1.0
		<?php endif; ?>
	</div>
	<strong>Copyright &copy; 2021 <a href="<?php echo base_url(); ?>">TIK BPOM Batam</a>.</strong> All rights reserved.
</footer>
